package vora.priya.utilities;

import java.io.IOException;

public interface FileReader {
	String read() throws IOException;
}
