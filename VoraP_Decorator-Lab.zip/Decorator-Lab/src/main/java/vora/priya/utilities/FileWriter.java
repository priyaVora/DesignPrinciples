package vora.priya.utilities;

import java.io.IOException;

public interface FileWriter {
	void write(String data) throws IOException;
}
